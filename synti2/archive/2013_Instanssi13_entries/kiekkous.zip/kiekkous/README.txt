"Kiekkous." 

Instanssi 2013 / Pikkiriikkinen demokompo (4k intro).


- 

Platform: Linux / x86-64 (code is intended to be cross-platform but I
haven't tried).

Libraries used: SDL, GL. Technologies: C, GLSL 1.1, Rosegarden, synti2
software synthesizer "protoslime version".

Synti2 is available from https://yousource.it.jyu.fi/synti2/synti2
(the code needs some surgery though, because I broke some things to
fit into 4k in todays compo...)
