"Synti2 protoslime." 

Instanssi 2013 / Summamutikka.

Nieminen pyrkii herättämään hämmennystä softalla, joka ei aivan
välttämättä kaadu ihan heti. (Eli pikkiriikkisen softasyntikan
status-raportti)

- 

Platform: Linux / x86-64 (code is intended to be cross-platform but I
haven't tried).

Synti2 is available from https://yousource.it.jyu.fi/synti2/synti2
(the code needs some surgery though, because I broke some things to
fit into 4k in todays compo...)
